#pragma once
// Local device configuration - git-ignored. Template: secrets.example.h
// Keep DEVICE_TOKEN identical to the esp32-node-1 entry of LANDSLIDE_DEVICE_TOKENS in ../../.env

// 2.4 GHz Wi-Fi (mobile hotspot)
#define WIFI_SSID     "Realme"
#define WIFI_PASSWORD "qwertyuiop"

// LAN IPv4 address of the laptop running the backend (printed by start.bat / start.sh).
// It can change when the hotspot reconnects.
#define API_HOST      "10.45.196.162"
#define API_PORT      8000

#define DEVICE_ID     "esp32-node-1"
#define DEVICE_TOKEN  "eM2HZmcSHzf3pf88TfYBQvJcMvD6w9p5"
